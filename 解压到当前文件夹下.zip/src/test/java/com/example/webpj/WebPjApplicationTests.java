package com.example.webpj;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebPjApplicationTests {

    @Test
    void contextLoads() {
    }

}
