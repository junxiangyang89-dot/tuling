export const environment = {
  production: true,
  apiUrl: '/api', // 生产环境使用相对路径，通过nginx代理
  wsUrl: '/ws'
}; 