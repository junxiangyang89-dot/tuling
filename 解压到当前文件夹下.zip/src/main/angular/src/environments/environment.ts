export const environment = {
  production: false,
  apiUrl: 'http://localhost:8080/api', // 开发环境使用完整URL
  wsUrl: 'http://localhost:8080/ws'

}; 